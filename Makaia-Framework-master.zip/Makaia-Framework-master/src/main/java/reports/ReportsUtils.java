package reports;

import com.aventstack.extentreports.IReport;

public class ReportsUtils implements IReport{
	

}
